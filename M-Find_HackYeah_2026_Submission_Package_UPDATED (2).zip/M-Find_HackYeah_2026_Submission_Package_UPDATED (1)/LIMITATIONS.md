# Known Limitations

- M-Find depends on the quality of the underlying location estimate.
- The prototype does not guarantee the exact physical position of the missing device.
- Search-priority information is guidance rather than proof of device presence.
- Browser shared-session synchronization is implemented but not fully validated across separate physical devices.
- Native HarmonyOS distributed integration is future work unless separately implemented and demonstrated.
- Indoor room/floor detection is not guaranteed.
- Online map tiles and external navigation may require internet connectivity.

# M-Find: Search Across Devices

HackYeah 2026 — Huawei Challenge: Imagine What's Next — HarmonyOS

## Submission position
The submitted M-Find HTML software is the integrated solution substantially developed during HackYeah 2026.

Before the Challenge, M-Find existed as an early experimental HTML proof of concept exploring guided search around an approximate device location. That earlier prototype is disclosed as the starting foundation.

During HackYeah, the project was substantially developed, integrated and refined into the submitted software, including the search-area/radius workflow, map-based recovery interface, searcher position, directional guidance, checkpoints, route assistance, sector/priority logic, searched-area progress, responsive interface, demonstration flow and HarmonyOS-oriented architecture.

## Shared Search status
The HTML includes a Searcher / Observer shared-session prototype with session ID, sector state, checkpoint controls, progress and activity history.

Browser synchronization logic is implemented using BroadcastChannel and localStorage.

Full validation across separate physical devices has not been completed. Native HarmonyOS distributed-device integration is future work unless separately demonstrated.

## Demo
1. Open the prototype.
2. Enter/use the approximate location.
3. Show the search circle and building/street context.
4. Start the guided search.
5. Demonstrate checkpoints/sectors/progress.
6. Open Shared Search and show Searcher / Observer modes.
7. If synchronization is demonstrated, state its current validation status accurately.

## Important limitation
M-Find does not claim exact device positioning when the device cannot be directly detected.

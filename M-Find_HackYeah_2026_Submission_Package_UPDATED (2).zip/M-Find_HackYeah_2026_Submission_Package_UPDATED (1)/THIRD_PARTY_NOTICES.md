# Third-Party / External Components

## Leaflet
Interactive browser mapping library.
Current prototype reference: Leaflet 1.9.4.

## OpenStreetMap / openstreetmap.de
The current prototype uses OpenStreetMap-derived geographic data / openstreetmap.de map tiles for street and building context and displays attribution.

## Standard Web APIs
The prototype uses browser capabilities including:
- Geolocation
- localStorage / Web Storage
- BroadcastChannel
- Service Worker where available

## Google Maps external hand-off
Some controls may open locations/routes externally in Google Maps.
Google Maps is not the core M-Find search engine.

## Final submission note
Verify the exact final dependency versions, licences and provider terms and retain all required attribution.

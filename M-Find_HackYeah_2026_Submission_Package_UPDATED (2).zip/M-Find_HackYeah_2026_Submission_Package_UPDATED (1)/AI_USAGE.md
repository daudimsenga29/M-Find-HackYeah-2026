# AI Usage Disclosure

OpenAI ChatGPT was used as a supporting tool for:
- concept refinement;
- HTML/CSS/JavaScript coding assistance;
- debugging and troubleshooting;
- responsive UI and map integration;
- architecture discussion;
- documentation and presentation drafting;
- selected conceptual image generation.

AI-assisted outputs were reviewed and integrated by the participant/team.
Final implementation choices, testing, project direction and submission responsibility remain with the participant/team.
